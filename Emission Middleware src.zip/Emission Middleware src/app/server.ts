import 'reflect-metadata';
import * as express from 'express';
import * as bodyParser from 'body-parser';
import * as cors from 'cors';
import { Server as httpServer } from 'http';
import { corsClientHost, serviceConfig } from './config';
import { Container } from 'typedi';
import { HTTP_SERVER_TOKEN } from './constants';
import { createProxyMiddleware } from 'http-proxy-middleware';
import {EWEdgeSdkService} from './services/edge-sdk.service';
export class Server {

    constructor(public app: express.Application) {
        this.app = express();
        if (this.app.get('env') === 'development') {
            this.app.use(cors({ origin: [corsClientHost], credentials: true }));
        }

        this.createMiddlewares();
    }
    public createsubscriptionRouter(){

        const edgeSdk = Container.get(EWEdgeSdkService);       
        
        this.app.use('/api/v1/subscription', edgeSdk._subscriptionRouter.router);


    }
public createMiddlewares(){
    this.app.use(bodyParser.json());
    this.app.use(bodyParser.urlencoded({ extended: false }));
}

}