import { Token } from 'typedi';

export const HTTP_SERVER_TOKEN = new Token('httpServer');
